package it.softphone.app.webphone

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel per la chat sincronizzata con WebPhone.
 *
 * Gestisce:
 *  - Lista conversazioni con badge messaggi non letti
 *  - Messaggi di una conversazione attiva
 *  - Invio messaggi e marcatura lettura
 *  - Aggiornamenti in tempo reale via SSE
 */
class WebPhoneChatViewModel(application: Application) : AndroidViewModel(application) {

    private val syncManager = WebPhoneSyncManager.getInstance(application)

    val conversations: StateFlow<List<WebPhoneConversation>> = syncManager.conversations
    val messages: StateFlow<Map<String, List<WebPhoneMessage>>> = syncManager.messages
    val unreadCount: StateFlow<Int> = syncManager.unreadCount

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    // -------------------------------------------------------------------------

    fun openConversation(conversationId: String) {
        _activeConversationId.value = conversationId
        viewModelScope.launch {
            syncManager.loadMessages(conversationId)
        }
    }

    fun messagesForConversation(conversationId: String): List<WebPhoneMessage> =
        syncManager.messages.value[conversationId] ?: emptyList()

    fun sendMessage(text: String, onResult: (Boolean) -> Unit = {}) {
        val convId = _activeConversationId.value ?: return
        syncManager.sendMessage(convId, text, onResult)
    }

    fun markAllRead(conversationId: String) {
        val msgs = messagesForConversation(conversationId)
            .filter { !it.isRead }
            .map { it.id }
        if (msgs.isNotEmpty()) {
            syncManager.markRead(conversationId, msgs)
        }
    }

    fun refreshConversations() {
        viewModelScope.launch {
            syncManager.refreshConversations()
        }
    }
}
