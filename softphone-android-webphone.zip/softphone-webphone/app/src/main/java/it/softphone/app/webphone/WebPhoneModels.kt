package it.softphone.app.webphone

/**
 * Record del log chiamate ricevuto da GET /api/calls
 */
data class WebPhoneCallRecord(
    val startedAt:   String,   // "2024-03-01 10:30:00"
    val direction:   String,   // "in" | "out"
    val number:      String,   // numero chiamante/chiamato
    val contactName: String,   // nome dalla rubrica (vuoto se sconosciuto)
    val status:      String,   // "answered" | "missed" | "failed"
    val duration:    Int       // secondi
)

/**
 * Conversazione chat ricevuta da GET /api/chat/conversations
 */
data class WebPhoneConversation(
    val id:            String,
    val subject:       String,
    val isGroup:       Boolean,
    val unreadCount:   Int,
    val lastMessage:   String,
    val lastActivity:  String,
    val peerExtension: String   // vuoto se gruppo
)

/**
 * Messaggio chat ricevuto da GET /api/chat/messages/:id
 */
data class WebPhoneMessage(
    val id:             String,
    val conversationId: String,
    val sender:         String,
    val body:           String,
    val sentAt:         String,
    val isRead:         Boolean,
    val edited:         Boolean
)

/**
 * Evento SSE ricevuto dallo stream /chat/stream
 */
sealed class WebPhoneSseEvent {
    data class NewMessage(val message: WebPhoneMessage) : WebPhoneSseEvent()
    data class MessagesRead(val conversationId: String, val messageIds: List<String>) : WebPhoneSseEvent()
    data class Typing(val conversationId: String, val extension: String) : WebPhoneSseEvent()
    data class GroupCreated(val conversationId: String) : WebPhoneSseEvent()
    data class SuppressRing(val ext: String, val caller: String, val display: String) : WebPhoneSseEvent()
    data class LinphoneStatus(val ext: String, val linphonePrimary: Boolean) : WebPhoneSseEvent()
    data class CallHistoryUpdated(val record: WebPhoneCallRecord) : WebPhoneSseEvent()
    object Unknown : WebPhoneSseEvent()
}

/**
 * Configurazione della connessione al server WebPhone.
 * Salvata nelle SharedPreferences con chiave PREF_KEY.
 */
data class WebPhoneConfig(
    val serverUrl: String,   // https://pbx199.esempio.it
    val username:  String,
    val password:  String,
    val extension: String    // extension SIP dell'utente (es. "201")
) {
    companion object {
        const val PREF_FILE = "webphone_config"
        const val KEY_SERVER   = "server_url"
        const val KEY_USERNAME = "username"
        const val KEY_PASSWORD = "password"
        const val KEY_EXTENSION = "extension"
    }

    val isValid: Boolean
        get() = serverUrl.isNotBlank() && username.isNotBlank() && password.isNotBlank()
}
