package it.softphone.app.webphone

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * WebPhoneSyncManager
 *
 * Singleton che coordina la sincronizzazione in tempo reale tra l'app
 * Android e il server WebPhone.
 *
 * Funzionalità gestite:
 *  1. Storico chiamate  — polling iniziale + aggiornamento SSE real-time
 *  2. Rubrica           — CardDAV via Linphone SDK (URL passato al CorePreferences)
 *  3. Chat              — conversazioni e messaggi via API REST + push SSE
 *
 * Ciclo di vita:
 *   • init(context, config) → da chiamare in LinphoneApplication.onCreate()
 *   • start() / stop()      → da CoreContext quando SIP si connette / disconnette
 */
class WebPhoneSyncManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "WebPhoneSyncManager"

        @Volatile private var instance: WebPhoneSyncManager? = null

        fun getInstance(context: Context): WebPhoneSyncManager =
            instance ?: synchronized(this) {
                instance ?: WebPhoneSyncManager(context.applicationContext).also { instance = it }
            }
    }

    // -------------------------------------------------------------------------
    // Stato pubblico (osservabile dai ViewModel)
    // -------------------------------------------------------------------------

    private val _callHistory  = MutableStateFlow<List<WebPhoneCallRecord>>(emptyList())
    val callHistory: StateFlow<List<WebPhoneCallRecord>> = _callHistory.asStateFlow()

    private val _conversations = MutableStateFlow<List<WebPhoneConversation>>(emptyList())
    val conversations: StateFlow<List<WebPhoneConversation>> = _conversations.asStateFlow()

    private val _messages = MutableStateFlow<Map<String, List<WebPhoneMessage>>>(emptyMap())
    val messages: StateFlow<Map<String, List<WebPhoneMessage>>> = _messages.asStateFlow()

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _unreadCount = MutableStateFlow(0)
    val unreadCount: StateFlow<Int> = _unreadCount.asStateFlow()

    // -------------------------------------------------------------------------
    // Internals
    // -------------------------------------------------------------------------

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var client: WebPhoneApiClient? = null
    private var sseListener: WebPhoneSseListener? = null
    private var config: WebPhoneConfig? = null

    // -------------------------------------------------------------------------
    // Inizializzazione e configurazione
    // -------------------------------------------------------------------------

    fun init(config: WebPhoneConfig) {
        this.config = config
        if (!config.isValid) {
            Log.w(TAG, "WebPhone config non valida, sync disabilitato")
            return
        }
        client = WebPhoneApiClient(config.serverUrl, config.username, config.password)
        Log.i(TAG, "WebPhoneSyncManager inizializzato → ${config.serverUrl} ext=${config.extension}")
    }

    /**
     * Carica la configurazione salvata nelle SharedPreferences e inizializza.
     * Da chiamare all'avvio se l'utente ha già configurato il WebPhone in precedenza.
     */
    fun initFromPrefs(context: Context) {
        val prefs: SharedPreferences = context.getSharedPreferences(
            WebPhoneConfig.PREF_FILE, Context.MODE_PRIVATE
        )
        val serverUrl  = prefs.getString(WebPhoneConfig.KEY_SERVER, "") ?: ""
        val username   = prefs.getString(WebPhoneConfig.KEY_USERNAME, "") ?: ""
        val password   = prefs.getString(WebPhoneConfig.KEY_PASSWORD, "") ?: ""
        val extension  = prefs.getString(WebPhoneConfig.KEY_EXTENSION, "") ?: ""

        if (serverUrl.isNotBlank() && username.isNotBlank()) {
            init(WebPhoneConfig(serverUrl, username, password, extension))
        }
    }

    /**
     * Salva la configurazione e reinizializza il client.
     */
    fun saveConfig(context: Context, newConfig: WebPhoneConfig) {
        context.getSharedPreferences(WebPhoneConfig.PREF_FILE, Context.MODE_PRIVATE)
            .edit()
            .putString(WebPhoneConfig.KEY_SERVER, newConfig.serverUrl)
            .putString(WebPhoneConfig.KEY_USERNAME, newConfig.username)
            .putString(WebPhoneConfig.KEY_PASSWORD, newConfig.password)
            .putString(WebPhoneConfig.KEY_EXTENSION, newConfig.extension)
            .apply()
        stop()
        init(newConfig)
        start()
    }

    // -------------------------------------------------------------------------
    // Start / Stop
    // -------------------------------------------------------------------------

    fun start() {
        val cfg = config ?: return
        val c   = client ?: return
        Log.i(TAG, "Start sync WebPhone")

        // 1. Carica storico chiamate iniziale
        scope.launch { refreshCallHistory() }

        // 2. Carica conversazioni chat iniziali
        scope.launch { refreshConversations() }

        // 3. Avvia SSE per aggiornamenti in tempo reale
        if (sseListener == null) {
            sseListener = WebPhoneSseListener(
                serverBaseUrl = cfg.serverUrl,
                username      = cfg.username,
                password      = cfg.password,
                onEvent       = ::handleSseEvent
            )
        }
        sseListener?.start()
        _isConnected.value = true
    }

    fun stop() {
        sseListener?.stop()
        sseListener = null
        _isConnected.value = false
        Log.i(TAG, "Stop sync WebPhone")
    }

    // -------------------------------------------------------------------------
    // Refresh manuale
    // -------------------------------------------------------------------------

    fun refreshCallHistory() {
        val c = client ?: return
        scope.launch {
            val records = c.fetchCallHistory(limit = 200)
            _callHistory.value = records
            Log.d(TAG, "Call history aggiornato: ${records.size} record")
        }
    }

    fun refreshConversations() {
        val c = client ?: return
        scope.launch {
            val convs = c.fetchConversations()
            _conversations.value = convs
            _unreadCount.value = convs.sumOf { it.unreadCount }
            Log.d(TAG, "Conversazioni aggiornate: ${convs.size}")
        }
    }

    fun loadMessages(conversationId: String) {
        val c = client ?: return
        scope.launch {
            val msgs = c.fetchMessages(conversationId)
            _messages.value = _messages.value.toMutableMap().also { it[conversationId] = msgs }
        }
    }

    // -------------------------------------------------------------------------
    // Azioni Chat
    // -------------------------------------------------------------------------

    fun sendMessage(conversationId: String, text: String, onResult: (Boolean) -> Unit = {}) {
        val c = client ?: run { onResult(false); return }
        scope.launch {
            val ok = c.sendMessage(conversationId, text)
            if (ok) refreshConversations()
            onResult(ok)
        }
    }

    fun markRead(conversationId: String, messageIds: List<String>) {
        val c = client ?: return
        scope.launch {
            c.markMessagesRead(conversationId, messageIds)
            refreshConversations()
        }
    }

    // -------------------------------------------------------------------------
    // Rubrica — URL CardDAV per il SDK Linphone
    // -------------------------------------------------------------------------

    /**
     * Restituisce l'URL CardDAV da passare a CorePreferences / account CardDAV.
     * Il Linphone SDK si occuperà di fare PROPFIND e sincronizzare i contatti.
     */
    fun cardDavUrl(): String? {
        val cfg = config ?: return null
        val ext = cfg.extension.ifBlank { return null }
        return client?.cardDavUrl(ext)
    }

    // -------------------------------------------------------------------------
    // Gestione eventi SSE
    // -------------------------------------------------------------------------

    private fun handleSseEvent(event: WebPhoneSseEvent) {
        when (event) {
            is WebPhoneSseEvent.NewMessage -> {
                // Aggiunge il messaggio alla conversazione in corso
                val current = _messages.value.toMutableMap()
                val convMsgs = current.getOrDefault(event.message.conversationId, emptyList())
                    .toMutableList()
                // Evita duplicati
                if (convMsgs.none { it.id == event.message.id }) {
                    convMsgs.add(event.message)
                    current[event.message.conversationId] = convMsgs
                    _messages.value = current
                }
                // Aggiorna contatore non letti
                refreshConversations()
            }

            is WebPhoneSseEvent.MessagesRead -> {
                val current = _messages.value.toMutableMap()
                current[event.conversationId] = current
                    .getOrDefault(event.conversationId, emptyList())
                    .map { msg ->
                        if (msg.id in event.messageIds) msg.copy(isRead = true) else msg
                    }
                _messages.value = current
                refreshConversations()
            }

            is WebPhoneSseEvent.Typing -> {
                // Propagato ai fragment via conversazioni (badge non cambia)
                Log.v(TAG, "Typing: ext=${event.extension} conv=${event.conversationId}")
            }

            is WebPhoneSseEvent.GroupCreated -> {
                refreshConversations()
            }

            is WebPhoneSseEvent.CallHistoryUpdated -> {
                // Aggiunge in testa il record appena terminato
                val updated = listOf(event.record) + _callHistory.value
                _callHistory.value = updated
            }

            is WebPhoneSseEvent.SuppressRing -> {
                // Notifica CoreContext per sopprimere il ring locale
                Log.i(TAG, "suppress_ring: ext=${event.ext} caller=${event.caller}")
                // CoreContext.onWebPhoneSuppressRing(event) verrà chiamato
                // tramite il callback registrato da CoreContext
                onSuppressRing?.invoke(event)
            }

            is WebPhoneSseEvent.LinphoneStatus -> {
                Log.i(TAG, "linphone_status: ext=${event.ext} primary=${event.linphonePrimary}")
                onLinphoneStatusChange?.invoke(event)
            }

            is WebPhoneSseEvent.Unknown -> { /* ignorato */ }
        }
    }

    // -------------------------------------------------------------------------
    // Callback per CoreContext
    // -------------------------------------------------------------------------

    var onSuppressRing: ((WebPhoneSseEvent.SuppressRing) -> Unit)? = null
    var onLinphoneStatusChange: ((WebPhoneSseEvent.LinphoneStatus) -> Unit)? = null
}
