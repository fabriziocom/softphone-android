/*
 * Copyright (c) 2010-2025 Belledonne Communications SARL.
 *
 * This file is part of linphone-android
 * (see https://www.linphone.org).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package it.softphone.app.ui.assistant.fragment

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.UiThread
import androidx.core.net.toUri
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import it.softphone.app.R
import it.softphone.app.core.tools.Log
import it.softphone.app.ui.GenericFragment
import it.softphone.app.databinding.AssistantRecoverAccountFragmentBinding
import it.softphone.app.ui.assistant.viewmodel.AccountCreationViewModel
import kotlin.getValue

@UiThread
class RecoverAccountFragment : GenericFragment() {
    companion object {
        private const val TAG = "[Recover Account Fragment]"
    }

    private lateinit var binding: AssistantRecoverAccountFragmentBinding

    private val viewModel: AccountCreationViewModel by navGraphViewModels(
        R.id.assistant_nav_graph
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = AssistantRecoverAccountFragmentBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel
        observeToastEvents(viewModel)

        viewModel.accountRecoveryTokenReceivedEvent.observe(viewLifecycleOwner) {
            it.consume { token ->
                Log.i("$TAG Account recovery token received [$token], opening browser")
                recoverPhoneNumberAccount(token)
            }
        }

        binding.setBackClickListener {
            goBack()
        }

        binding.setRecoverEmailAccountClickListener {
            recoverEmailAccount()
        }

        binding.setRecoverPhoneNumberAccountClickListener {
            viewModel.requestAccountRecoveryToken()
        }
    }

    private fun goBack() {
        findNavController().popBackStack()
    }

    private fun recoverEmailAccount() {
        val rootUrl = getString(R.string.web_platform_forgotten_password_url)
        val url = "$rootUrl/recovery/email"
        try {
            Log.i("$TAG Trying to open [$url] URL")
            val browserIntent = Intent(Intent.ACTION_VIEW, url.toUri())
            startActivity(browserIntent)
        } catch (ise: IllegalStateException) {
            Log.e(
                "$TAG Can't start ACTION_VIEW intent for URL [$url], IllegalStateException: $ise"
            )
        } catch (anfe: ActivityNotFoundException) {
            Log.e(
                "$TAG Can't start ACTION_VIEW intent for URL [$url], ActivityNotFoundException: $anfe"
            )
        } catch (e: Exception) {
            Log.e(
                "$TAG Can't start ACTION_VIEW intent for URL [$url]: $e"
            )
        }
    }

    private fun recoverPhoneNumberAccount(recoveryToken: String) {
        val rootUrl = getString(R.string.web_platform_forgotten_password_url)
        val url = "$rootUrl/recovery/phone/$recoveryToken"
        try {
            Log.i("$TAG Trying to open [$url] URL")
            val browserIntent = Intent(Intent.ACTION_VIEW, url.toUri())
            startActivity(browserIntent)
        } catch (ise: IllegalStateException) {
            Log.e(
                "$TAG Can't start ACTION_VIEW intent for URL [$url], IllegalStateException: $ise"
            )
        } catch (anfe: ActivityNotFoundException) {
            Log.e(
                "$TAG Can't start ACTION_VIEW intent for URL [$url], ActivityNotFoundException: $anfe"
            )
        } catch (e: Exception) {
            Log.e(
                "$TAG Can't start ACTION_VIEW intent for URL [$url]: $e"
            )
        }
    }
}
