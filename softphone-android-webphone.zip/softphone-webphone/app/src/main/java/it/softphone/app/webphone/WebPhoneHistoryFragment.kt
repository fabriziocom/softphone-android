package it.softphone.app.webphone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.softphone.app.R
import kotlinx.coroutines.launch

/**
 * WebPhoneHistoryFragment
 *
 * Mostra lo storico chiamate sincronizzato con il WebPhone.
 * Si aggiorna in tempo reale via SSE: quando una chiamata si chiude,
 * appare immediatamente in cima alla lista.
 *
 * Integrazione nel progetto:
 *   Sostituisce o affianca HistoryListFragment — il ViewModel nativo
 *   di Linphone mostra i CallLog locali, mentre questo fragment mostra
 *   lo storico centralizzato del PBX (identico a quello del WebPhone).
 */
class WebPhoneHistoryFragment : Fragment() {

    private val viewModel: WebPhoneHistoryViewModel by viewModels()
    private lateinit var rvHistory: RecyclerView
    private lateinit var tvEmpty: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_webphone_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvHistory = view.findViewById(R.id.rv_webphone_history)
        tvEmpty   = view.findViewById(R.id.tv_webphone_history_empty)

        rvHistory.layoutManager = LinearLayoutManager(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.callHistory.collect { records ->
                    if (records.isEmpty()) {
                        tvEmpty.visibility = View.VISIBLE
                        rvHistory.visibility = View.GONE
                    } else {
                        tvEmpty.visibility = View.GONE
                        rvHistory.visibility = View.VISIBLE
                        rvHistory.adapter = WebPhoneHistoryAdapter(records)
                    }
                }
            }
        }

        viewModel.refresh()
    }
}

// ---------------------------------------------------------------------------
// RecyclerView Adapter
// ---------------------------------------------------------------------------

class WebPhoneHistoryAdapter(
    private val items: List<WebPhoneCallRecord>
) : RecyclerView.Adapter<WebPhoneHistoryAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvNumber:   TextView = view.findViewById(R.id.tv_call_number)
        val tvContact:  TextView = view.findViewById(R.id.tv_call_contact)
        val tvDate:     TextView = view.findViewById(R.id.tv_call_date)
        val tvStatus:   TextView = view.findViewById(R.id.tv_call_status)
        val tvDuration: TextView = view.findViewById(R.id.tv_call_duration)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_webphone_call, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = items[position]

        holder.tvNumber.text  = r.number
        holder.tvContact.text = r.contactName.ifBlank { r.number }
        holder.tvDate.text    = r.startedAt.take(16)

        // Icona / testo direzione + stato
        val dirLabel = if (r.direction == "in") "▼ Entrata" else "▲ Uscita"
        val statusLabel = when (r.status) {
            "answered" -> "✅ $dirLabel"
            "missed"   -> "❌ Persa"
            "failed"   -> "⚠️ Fallita"
            else       -> dirLabel
        }
        holder.tvStatus.text = statusLabel

        // Durata
        if (r.duration > 0) {
            val min = r.duration / 60
            val sec = r.duration % 60
            holder.tvDuration.text = "%d:%02d".format(min, sec)
            holder.tvDuration.visibility = View.VISIBLE
        } else {
            holder.tvDuration.visibility = View.GONE
        }
    }

    override fun getItemCount() = items.size
}
