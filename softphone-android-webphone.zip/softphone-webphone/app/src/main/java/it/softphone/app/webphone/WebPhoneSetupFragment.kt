package it.softphone.app.webphone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import it.softphone.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * WebPhoneSetupFragment
 *
 * Schermata di configurazione della connessione al server WebPhone.
 * Viene mostrata al primo avvio o da Impostazioni → WebPhone.
 *
 * L'utente inserisce:
 *   - URL del server  (es. https://pbx199.esempio.it)
 *   - Username        (stesso del WebPhone)
 *   - Password        (stessa del WebPhone)
 *
 * Al salvataggio:
 *  1. Verifica le credenziali chiamando GET /api/linphone/provision
 *  2. Estrae extension, proxy SIP e CardDAV URL dal provisioning XML
 *  3. Salva la config e avvia WebPhoneSyncManager
 *
 * In alternativa l'utente può usare il QR code generato dal WebPhone
 * (menu utente → Linphone → QR code) tramite il QrCodeScannerFragment
 * già presente nell'app.
 */
class WebPhoneSetupFragment : Fragment() {

    private lateinit var etServerUrl: EditText
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnSave: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Usa layout inline — in un progetto reale questo sarebbe un XML separato
        return inflater.inflate(R.layout.fragment_webphone_setup, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etServerUrl  = view.findViewById(R.id.et_webphone_server_url)
        etUsername   = view.findViewById(R.id.et_webphone_username)
        etPassword   = view.findViewById(R.id.et_webphone_password)
        btnSave      = view.findViewById(R.id.btn_webphone_save)
        progressBar  = view.findViewById(R.id.webphone_setup_progress)
        tvStatus     = view.findViewById(R.id.tv_webphone_status)

        // Pre-popola se esiste già una config salvata
        loadSavedConfig()

        btnSave.setOnClickListener { saveAndVerify() }
    }

    private fun loadSavedConfig() {
        val prefs = requireContext().getSharedPreferences(WebPhoneConfig.PREF_FILE, 0)
        etServerUrl.setText(prefs.getString(WebPhoneConfig.KEY_SERVER, ""))
        etUsername.setText(prefs.getString(WebPhoneConfig.KEY_USERNAME, ""))
        // password non pre-popolata per sicurezza
    }

    private fun saveAndVerify() {
        val serverUrl = etServerUrl.text.toString().trimEnd('/')
        val username  = etUsername.text.toString().trim()
        val password  = etPassword.text.toString()

        if (serverUrl.isBlank() || username.isBlank() || password.isBlank()) {
            Toast.makeText(requireContext(), "Compila tutti i campi", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.visibility = View.VISIBLE
        btnSave.isEnabled = false
        tvStatus.text = "Verifica connessione…"

        lifecycleScope.launch {
            val result = verifyAndExtract(serverUrl, username, password)
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                btnSave.isEnabled = true
                if (result == null) {
                    tvStatus.text = "❌ Connessione fallita. Controlla URL e credenziali."
                } else {
                    tvStatus.text = "✅ Connesso come extension ${result.extension}"
                    val mgr = WebPhoneSyncManager.getInstance(requireContext())
                    mgr.saveConfig(requireContext(), result)
                    parentFragmentManager.popBackStack()
                }
            }
        }
    }

    private suspend fun verifyAndExtract(
        serverUrl: String,
        username: String,
        password: String
    ): WebPhoneConfig? = withContext(Dispatchers.IO) {
        try {
            val client = WebPhoneApiClient(serverUrl, username, password)
            val xml = client.fetchProvisioningXml() ?: return@withContext null

            // Estrai extension dall'XML di provisioning
            // <username>201</username>  oppure  identity="sip:201@pbx..."
            val extMatch = Regex("""identity="sip:(\d+)@""").find(xml)
                ?: Regex("""<username>(\w+)</username>""").find(xml)
            val extension = extMatch?.groupValues?.get(1) ?: username

            WebPhoneConfig(
                serverUrl = serverUrl,
                username  = username,
                password  = password,
                extension = extension
            )
        } catch (e: Exception) {
            null
        }
    }
}
