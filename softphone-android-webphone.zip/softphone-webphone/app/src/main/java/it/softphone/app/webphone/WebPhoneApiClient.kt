package it.softphone.app.webphone

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/**
 * WebPhoneApiClient
 *
 * Gestisce tutte le chiamate HTTP verso il server WebPhone.
 * Endpoint usati:
 *   GET  /api/calls                       → storico chiamate (CDR)
 *   GET  /api/linphone/provision           → provisioning XML SIP
 *   GET  /api/linphone/carddav/:ext/       → rubrica CardDAV
 *   GET  /api/linphone/status              → stato "linphone primario"
 *   POST /api/linphone/status              → aggiorna stato
 *   GET  /chat/conversations               → lista conversazioni
 *   GET  /chat/messages/:convId            → messaggi di una conversazione
 *   POST /chat/send                        → invia messaggio
 *   POST /chat/read                        → marca messaggi come letti
 *
 * Autenticazione: HTTP Basic con username e password WebPhone.
 * Una volta autenticati il server restituisce un cookie di sessione che
 * viene mantenuto dal CookieManager di sistema.
 */
class WebPhoneApiClient(
    private val serverBaseUrl: String,   // es. "https://pbx199.esempio.it"
    private val username: String,
    private val password: String
) {

    companion object {
        private const val TAG = "WebPhoneApiClient"
        private const val TIMEOUT_MS = 15_000
    }

    // -------------------------------------------------------------------------
    // Autenticazione Basic
    // -------------------------------------------------------------------------

    private fun basicAuthHeader(): String {
        val credentials = "$username:$password"
        return "Basic " + Base64.encodeToString(credentials.toByteArray(), Base64.NO_WRAP)
    }

    // -------------------------------------------------------------------------
    // Helper HTTP
    // -------------------------------------------------------------------------

    private suspend fun get(path: String): String? = withContext(Dispatchers.IO) {
        try {
            val url = URL("$serverBaseUrl$path")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                setRequestProperty("Authorization", basicAuthHeader())
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                Log.w(TAG, "GET $path → HTTP $code")
                return@withContext null
            }
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.e(TAG, "GET $path failed: ${e.message}")
            null
        }
    }

    private suspend fun post(path: String, body: JSONObject): String? = withContext(Dispatchers.IO) {
        try {
            val url = URL("$serverBaseUrl$path")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                doOutput = true
                setRequestProperty("Authorization", basicAuthHeader())
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            if (code !in 200..299) {
                Log.w(TAG, "POST $path → HTTP $code")
                return@withContext null
            }
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            Log.e(TAG, "POST $path failed: ${e.message}")
            null
        }
    }

    // -------------------------------------------------------------------------
    // Storico Chiamate (CDR)
    // -------------------------------------------------------------------------

    /**
     * Recupera il log chiamate dal server WebPhone.
     * @param limit  numero massimo di record (default 100, max 500)
     * @param page   pagina (default 1)
     * @param status "answered" | "missed" | "failed" | null = tutti
     */
    suspend fun fetchCallHistory(
        limit: Int = 100,
        page: Int = 1,
        status: String? = null
    ): List<WebPhoneCallRecord> {
        var path = "/api/calls?limit=$limit&page=$page"
        if (status != null) path += "&status=$status"
        val raw = get(path) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                WebPhoneCallRecord(
                    startedAt   = o.optString("started_at"),
                    direction   = o.optString("direction"),
                    number      = o.optString("number"),
                    contactName = o.optString("contact_name"),
                    status      = o.optString("status"),
                    duration    = o.optInt("duration", 0)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchCallHistory parse error: ${e.message}")
            emptyList()
        }
    }

    // -------------------------------------------------------------------------
    // Rubrica (CardDAV)
    // -------------------------------------------------------------------------

    /**
     * Recupera la lista vCard dall'endpoint CardDAV del WebPhone.
     * Ritorna il body XML grezzo (formato PROPFIND multistatus).
     * Il risultato viene passato direttamente al ContactsManager come
     * source CardDAV oppure salvato localmente per l'import.
     */
    suspend fun fetchCardDavRaw(extension: String): String? =
        get("/api/linphone/carddav/$extension/")

    /**
     * URL completo dell'endpoint CardDAV da passare al SDK Linphone
     * per la sincronizzazione automatica della rubrica.
     */
    fun cardDavUrl(extension: String): String =
        "$serverBaseUrl/api/linphone/carddav/$extension/"

    // -------------------------------------------------------------------------
    // Provisioning XML
    // -------------------------------------------------------------------------

    /**
     * Scarica il file XML di provisioning per configurare automaticamente
     * l'account SIP, il proxy Asterisk, ICE/TURN e la rubrica CardDAV.
     */
    suspend fun fetchProvisioningXml(): String? =
        get("/api/linphone/provision")

    // -------------------------------------------------------------------------
    // Stato "Linphone Primario"
    // -------------------------------------------------------------------------

    data class LinphoneStatus(val linphonePrimary: Boolean, val extension: String)

    suspend fun fetchLinphoneStatus(): LinphoneStatus? {
        val raw = get("/api/linphone/status") ?: return null
        return try {
            val o = JSONObject(raw)
            LinphoneStatus(
                linphonePrimary = o.optBoolean("linphone_primary", false),
                extension       = o.optString("extension", "")
            )
        } catch (e: Exception) { null }
    }

    suspend fun setLinphonePrimary(enabled: Boolean): Boolean {
        val body = JSONObject().put("linphone_primary", enabled)
        return post("/api/linphone/status", body) != null
    }

    // -------------------------------------------------------------------------
    // Chat — Conversazioni
    // -------------------------------------------------------------------------

    suspend fun fetchConversations(): List<WebPhoneConversation> {
        val raw = get("/api/chat/conversations") ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                WebPhoneConversation(
                    id           = o.optString("id"),
                    subject      = o.optString("subject"),
                    isGroup      = o.optBoolean("is_group", false),
                    unreadCount  = o.optInt("unread_count", 0),
                    lastMessage  = o.optString("last_message"),
                    lastActivity = o.optString("last_activity"),
                    peerExtension = o.optString("peer_extension")
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchConversations parse error: ${e.message}")
            emptyList()
        }
    }

    // -------------------------------------------------------------------------
    // Chat — Messaggi
    // -------------------------------------------------------------------------

    suspend fun fetchMessages(conversationId: String, before: String? = null): List<WebPhoneMessage> {
        var path = "/api/chat/messages/$conversationId"
        if (before != null) path += "?before=$before"
        val raw = get(path) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                WebPhoneMessage(
                    id             = o.optString("id"),
                    conversationId = conversationId,
                    sender         = o.optString("sender"),
                    body           = o.optString("body"),
                    sentAt         = o.optString("sent_at"),
                    isRead         = o.optBoolean("is_read", false),
                    edited         = o.optBoolean("edited", false)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchMessages parse error: ${e.message}")
            emptyList()
        }
    }

    suspend fun sendMessage(conversationId: String, text: String): Boolean {
        val body = JSONObject()
            .put("conversationId", conversationId)
            .put("body", text)
        return post("/api/chat/send", body) != null
    }

    suspend fun markMessagesRead(conversationId: String, messageIds: List<String>): Boolean {
        val arr = JSONArray(messageIds)
        val body = JSONObject()
            .put("conversationId", conversationId)
            .put("messageIds", arr)
        return post("/api/chat/read", body) != null
    }

    /**
     * Apre una nuova conversazione 1-to-1 con un'altra extension.
     * Restituisce l'id della conversazione creata o esistente.
     */
    suspend fun openOrCreateConversation(peerExtension: String): String? {
        val body = JSONObject()
            .put("peerExtension", peerExtension)
            .put("body", "")
        val raw = post("/api/chat/send", body) ?: return null
        return try { JSONObject(raw).optString("conversation_id") } catch (e: Exception) { null }
    }
}
