package it.softphone.app.webphone

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel per lo storico chiamate sincronizzato con WebPhone.
 *
 * I Fragment della History possono osservare [callHistory] per ricevere
 * aggiornamenti in tempo reale (push SSE quando una chiamata si chiude).
 *
 * Sostituisce / affianca il ViewModel nativo di Linphone:
 *  - Se WebPhone è configurato: usa i dati del server (più affidabili, sincronizzati su tutti i device)
 *  - Altrimenti: fallback ai CallLog locali del SDK
 */
class WebPhoneHistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val syncManager = WebPhoneSyncManager.getInstance(application)

    /** Lista chiamate aggiornata in tempo reale */
    val callHistory: StateFlow<List<WebPhoneCallRecord>> = syncManager.callHistory

    /** Solo chiamate perse */
    val missedCalls: StateFlow<List<WebPhoneCallRecord>> = syncManager.callHistory
        .map { list -> list.filter { it.status == "missed" } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Numero di chiamate perse non lette */
    val missedCount: StateFlow<Int> = missedCalls
        .map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    /** True se il server WebPhone è configurato */
    val isWebPhoneConfigured: Boolean get() = syncManager.isConnected.value

    fun refresh() {
        viewModelScope.launch {
            syncManager.refreshCallHistory()
        }
    }
}
