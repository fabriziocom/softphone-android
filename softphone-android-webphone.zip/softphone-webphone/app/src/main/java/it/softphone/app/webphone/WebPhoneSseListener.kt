package it.softphone.app.webphone

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/**
 * WebPhoneSseListener
 *
 * Si connette all'endpoint Server-Sent Events del WebPhone e notifica
 * in tempo reale ogni evento tramite [WebPhoneSyncManager].
 *
 * Endpoint SSE WebPhone:
 *   GET /chat/stream         → nuovi messaggi, letture, typing, gruppi
 *   SSE event: suppress_ring → chiamata in arrivo con Linphone primario attivo
 *   SSE event: linphone_status → cambio stato toggle "Linphone primario"
 *   SSE event: call_ended / call_answered → aggiornamento storico in tempo reale
 *
 * In caso di disconnessione la classe effettua reconnect automatico
 * con backoff esponenziale (max 60 s).
 */
class WebPhoneSseListener(
    private val serverBaseUrl: String,
    private val username: String,
    private val password: String,
    private val onEvent: (WebPhoneSseEvent) -> Unit
) {
    companion object {
        private const val TAG = "WebPhoneSseListener"
        private const val INITIAL_RETRY_MS = 3_000L
        private const val MAX_RETRY_MS = 60_000L
    }

    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch { connectLoop() }
        Log.i(TAG, "SSE listener started → $serverBaseUrl/chat/stream")
    }

    fun stop() {
        job?.cancel()
        job = null
        Log.i(TAG, "SSE listener stopped")
    }

    private suspend fun connectLoop() {
        var retryMs = INITIAL_RETRY_MS
        while (isActive) {
            try {
                connect()
                retryMs = INITIAL_RETRY_MS  // reset after clean disconnect
            } catch (e: Exception) {
                Log.w(TAG, "SSE connection lost: ${e.message} — retry in ${retryMs}ms")
            }
            if (!isActive) break
            delay(retryMs)
            retryMs = minOf(retryMs * 2, MAX_RETRY_MS)
        }
    }

    private fun connect() {
        val credentials = "$username:$password"
        val auth = "Basic " + Base64.encodeToString(credentials.toByteArray(), Base64.NO_WRAP)

        val url = URL("$serverBaseUrl/chat/stream")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 0   // SSE: no timeout on read
            setRequestProperty("Authorization", auth)
            setRequestProperty("Accept", "text/event-stream")
            setRequestProperty("Cache-Control", "no-cache")
        }

        val code = conn.responseCode
        if (code != 200) {
            conn.disconnect()
            throw Exception("HTTP $code")
        }

        BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { reader ->
            var eventType = ""
            val dataBuf = StringBuilder()

            reader.forEachLine { line ->
                when {
                    line.startsWith("event:") -> {
                        eventType = line.removePrefix("event:").trim()
                    }
                    line.startsWith("data:") -> {
                        dataBuf.append(line.removePrefix("data:").trim())
                    }
                    line.isEmpty() && dataBuf.isNotEmpty() -> {
                        // Dispatch event
                        dispatchEvent(eventType, dataBuf.toString())
                        eventType = ""
                        dataBuf.clear()
                    }
                }
            }
        }
        conn.disconnect()
    }

    private fun dispatchEvent(type: String, data: String) {
        val event: WebPhoneSseEvent = try {
            val json = JSONObject(data)
            when (type) {
                "new_message" -> WebPhoneSseEvent.NewMessage(
                    WebPhoneMessage(
                        id             = json.optString("id"),
                        conversationId = json.optString("conversation_id"),
                        sender         = json.optString("sender"),
                        body           = json.optString("body"),
                        sentAt         = json.optString("sent_at"),
                        isRead         = json.optBoolean("is_read", false),
                        edited         = false
                    )
                )
                "messages_read" -> WebPhoneSseEvent.MessagesRead(
                    conversationId = json.optString("conversation_id"),
                    messageIds     = buildList {
                        val arr = json.optJSONArray("message_ids")
                        if (arr != null) repeat(arr.length()) { add(arr.getString(it)) }
                    }
                )
                "typing" -> WebPhoneSseEvent.Typing(
                    conversationId = json.optString("conversation_id"),
                    extension      = json.optString("extension")
                )
                "group_created" -> WebPhoneSseEvent.GroupCreated(
                    conversationId = json.optString("id")
                )
                "suppress_ring" -> WebPhoneSseEvent.SuppressRing(
                    ext     = json.optString("ext"),
                    caller  = json.optString("caller"),
                    display = json.optString("display")
                )
                "linphone_status" -> WebPhoneSseEvent.LinphoneStatus(
                    ext            = json.optString("ext"),
                    linphonePrimary = json.optBoolean("linphone_primary", false)
                )
                "call_ended", "call_answered", "call_missed" -> {
                    // Aggiorna storico chiamate in tempo reale
                    WebPhoneSseEvent.CallHistoryUpdated(
                        WebPhoneCallRecord(
                            startedAt   = json.optString("started_at"),
                            direction   = json.optString("direction"),
                            number      = json.optString("number"),
                            contactName = json.optString("contact_name"),
                            status      = json.optString("status"),
                            duration    = json.optInt("duration", 0)
                        )
                    )
                }
                else -> WebPhoneSseEvent.Unknown
            }
        } catch (e: Exception) {
            Log.w(TAG, "SSE parse error type=$type: ${e.message}")
            WebPhoneSseEvent.Unknown
        }

        if (event !is WebPhoneSseEvent.Unknown) {
            onEvent(event)
        }
    }
}
