package it.softphone.app.webphone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.softphone.app.R
import kotlinx.coroutines.launch

/**
 * WebPhoneChatFragment
 *
 * Mostra le conversazioni sincronizzate con il WebPhone.
 * Usato come Tab "Chat" nel bottom nav — si affianca/sostituisce la
 * chat nativa di Linphone quando il WebPhone è configurato.
 *
 * Layout:
 *  - Lista conversazioni (RecyclerView) con badge messaggi non letti
 *  - Al click → apre la lista messaggi della conversazione
 *  - Campo testo + pulsante invia per rispondere
 */
class WebPhoneChatFragment : Fragment() {

    private val viewModel: WebPhoneChatViewModel by viewModels()

    private lateinit var rvConversations: RecyclerView
    private lateinit var tvEmpty: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_webphone_chat, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvConversations = view.findViewById(R.id.rv_webphone_conversations)
        tvEmpty = view.findViewById(R.id.tv_webphone_chat_empty)

        rvConversations.layoutManager = LinearLayoutManager(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.conversations.collect { convs ->
                    if (convs.isEmpty()) {
                        tvEmpty.visibility = View.VISIBLE
                        rvConversations.visibility = View.GONE
                    } else {
                        tvEmpty.visibility = View.GONE
                        rvConversations.visibility = View.VISIBLE
                        rvConversations.adapter = WebPhoneConversationsAdapter(convs) { conv ->
                            openConversation(conv)
                        }
                    }
                }
            }
        }

        viewModel.refreshConversations()
    }

    private fun openConversation(conv: WebPhoneConversation) {
        viewModel.openConversation(conv.id)
        val fragment = WebPhoneMessagesFragment.newInstance(conv.id, conv.subject)
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack("webphone_messages_${conv.id}")
            .commit()
    }
}

// ---------------------------------------------------------------------------
// RecyclerView Adapter per le conversazioni
// ---------------------------------------------------------------------------

class WebPhoneConversationsAdapter(
    private val items: List<WebPhoneConversation>,
    private val onClick: (WebPhoneConversation) -> Unit
) : RecyclerView.Adapter<WebPhoneConversationsAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView    = view.findViewById(R.id.tv_conv_name)
        val tvLast: TextView    = view.findViewById(R.id.tv_conv_last)
        val tvBadge: TextView   = view.findViewById(R.id.tv_conv_badge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_webphone_conversation, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val conv = items[position]
        holder.tvName.text = conv.subject.ifBlank { conv.peerExtension }
        holder.tvLast.text = conv.lastMessage
        if (conv.unreadCount > 0) {
            holder.tvBadge.visibility = View.VISIBLE
            holder.tvBadge.text = conv.unreadCount.toString()
        } else {
            holder.tvBadge.visibility = View.GONE
        }
        holder.itemView.setOnClickListener { onClick(conv) }
    }

    override fun getItemCount() = items.size
}

// ---------------------------------------------------------------------------
// Fragment messaggi di una conversazione
// ---------------------------------------------------------------------------

class WebPhoneMessagesFragment : Fragment() {

    companion object {
        private const val ARG_CONV_ID   = "conv_id"
        private const val ARG_CONV_NAME = "conv_name"

        fun newInstance(convId: String, convName: String) = WebPhoneMessagesFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_CONV_ID, convId)
                putString(ARG_CONV_NAME, convName)
            }
        }
    }

    private val viewModel: WebPhoneChatViewModel by viewModels()
    private lateinit var convId: String
    private lateinit var rvMessages: RecyclerView
    private lateinit var etInput: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var tvTyping: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        convId = requireArguments().getString(ARG_CONV_ID)!!
        return inflater.inflate(R.layout.fragment_webphone_messages, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvMessages = view.findViewById(R.id.rv_webphone_messages)
        etInput    = view.findViewById(R.id.et_webphone_message_input)
        btnSend    = view.findViewById(R.id.btn_webphone_send)
        tvTyping   = view.findViewById(R.id.tv_webphone_typing)

        val llm = LinearLayoutManager(requireContext()).apply { stackFromEnd = true }
        rvMessages.layoutManager = llm

        // Osserva messaggi in tempo reale
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.messages.collect { allMessages ->
                    val msgs = allMessages[convId] ?: return@collect
                    rvMessages.adapter = WebPhoneMessagesAdapter(msgs)
                    rvMessages.scrollToPosition(msgs.size - 1)
                    // Marca come letti
                    viewModel.markAllRead(convId)
                }
            }
        }

        btnSend.setOnClickListener {
            val text = etInput.text.toString().trim()
            if (text.isNotBlank()) {
                viewModel.sendMessage(text)
                etInput.text.clear()
            }
        }

        viewModel.openConversation(convId)
    }
}

// ---------------------------------------------------------------------------
// RecyclerView Adapter per i messaggi
// ---------------------------------------------------------------------------

class WebPhoneMessagesAdapter(
    private val items: List<WebPhoneMessage>
) : RecyclerView.Adapter<WebPhoneMessagesAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvBody: TextView   = view.findViewById(R.id.tv_msg_body)
        val tvSender: TextView = view.findViewById(R.id.tv_msg_sender)
        val tvTime: TextView   = view.findViewById(R.id.tv_msg_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_webphone_message, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val msg = items[position]
        holder.tvBody.text   = msg.body
        holder.tvSender.text = msg.sender
        holder.tvTime.text   = msg.sentAt.take(16)  // "YYYY-MM-DD HH:MM"
    }

    override fun getItemCount() = items.size
}
