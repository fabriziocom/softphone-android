/*
 * Copyright (c) 2010-2023 Belledonne Communications SARL.
 *
 * This file is part of linphone-android
 * (see https://www.linphone.org).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package it.softphone.app.telecom

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.core.telecom.CallAttributesCompat
import androidx.core.telecom.CallException
import androidx.core.telecom.CallsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import it.softphone.app.LinphoneApplication.Companion.coreContext
import it.softphone.app.core.Call
import it.softphone.app.core.Core
import it.softphone.app.core.CoreListenerStub
import it.softphone.app.core.tools.Log
import it.softphone.app.utils.LinphoneUtils
import androidx.core.net.toUri

class TelecomManager
    @WorkerThread
    constructor(context: Context) {
    companion object {
        private const val TAG = "[Telecom Manager]"
    }

    private val callsManager = CallsManager(context)

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val map = HashMap<String, TelecomCallControlCallback>()

    private val coreListener = object : CoreListenerStub() {
        @WorkerThread
        override fun onCallStateChanged(
            core: Core,
            call: Call,
            state: Call.State?,
            message: String
        ) {
            if (state == Call.State.IncomingReceived || state == Call.State.OutgoingProgress) {
                onCallCreated(call)
            }
        }

        @WorkerThread
        override fun onLastCallEnded(core: Core) {
            currentlyFollowedCalls = 0
        }
    }

    private val hasTelecomFeature = context.packageManager.hasSystemFeature("android.software.telecom")

    private var currentlyFollowedCalls: Int = 0

    init {
        Log.i(
            "$TAG android.software.telecom feature is [${if (hasTelecomFeature) "available" else "not available"}]"
        )
        try {
            callsManager.registerAppWithTelecom(CallsManager.CAPABILITY_SUPPORTS_VIDEO_CALLING)
            Log.i("$TAG App has been registered with Telecom")
        } catch (e: Exception) {
            Log.e("$TAG Can't init TelecomManager: $e")
        }
    }

    @WorkerThread
    fun onCallCreated(call: Call) {
        Log.i("$TAG Call to [${call.remoteAddress.asStringUriOnly()}] created in state [${call.state}]")

        val address = call.callLog.remoteAddress
        val uri = address.asStringUriOnly().toUri()

        val direction = if (call.dir == Call.Dir.Outgoing) {
            CallAttributesCompat.DIRECTION_OUTGOING
        } else {
            CallAttributesCompat.DIRECTION_INCOMING
        }

        val capabilities = CallAttributesCompat.SUPPORTS_SET_INACTIVE or CallAttributesCompat.SUPPORTS_TRANSFER

        val conferenceInfo = LinphoneUtils.getConferenceInfoIfAny(call)
        val displayName = if (call.conference != null || conferenceInfo != null) {
            conferenceInfo?.subject ?: call.conference?.subject ?: LinphoneUtils.getDisplayName(address)
        } else {
            val friend = coreContext.contactsManager.findContactByAddress(address)
            friend?.name ?: LinphoneUtils.getDisplayName(address)
        }

        // Always set type to video (if enabled in Core) as it indicates that video is supported, not that it's being used at the time
        // https://developer.android.com/reference/kotlin/androidx/core/telecom/CallAttributesCompat#CALL_TYPE_VIDEO_CALL()
        val type = if (!call.core.isVideoEnabled) {
            CallAttributesCompat.CALL_TYPE_AUDIO_CALL
        } else {
            CallAttributesCompat.CALL_TYPE_VIDEO_CALL
        }

        scope.launch {
            try {
                val callAttributes = CallAttributesCompat(
                    displayName,
                    uri,
                    direction,
                    type,
                    capabilities
                )
                Log.i("$TAG Adding call to Telecom's CallsManager with attributes [$callAttributes]")

                callsManager.addCall(
                    callAttributes,
                    { callType -> // onAnswer
                        Log.i("$TAG We're asked to answer the call with type [$callType]")
                        coreContext.postOnCoreThread {
                            if (LinphoneUtils.isCallIncoming(call.state)) {
                                Log.i("$TAG Answering call")
                                coreContext.answerCall(call)
                            }
                        }
                    },
                    { disconnectCause -> // onDisconnect
                        Log.i(
                            "$TAG We're asked to terminate the call with reason [$disconnectCause]"
                        )
                        coreContext.postOnCoreThread {
                            coreContext.terminateCall(call)
                        }
                        currentlyFollowedCalls -= 1
                    },
                    { // onSetActive
                        Log.i("$TAG We're asked to resume the call")
                        coreContext.postOnCoreThread {
                            Log.i("$TAG Resuming call")
                            call.resume()
                        }
                    },
                    { // onSetInactive
                        Log.i("$TAG We're asked to pause the call")
                        coreContext.postOnCoreThread {
                            Log.i("$TAG Pausing call")
                            call.pause()
                        }
                    }
                ) {
                    val callbacks = TelecomCallControlCallback(call, this, scope)

                    // We must first call setCallback on callControlScope before using it
                    callbacks.onCallControlCallbackSet()
                    currentlyFollowedCalls += 1
                    Log.i("$TAG Call added to Telecom's CallsManager")

                    coreContext.postOnCoreThread {
                        val callId = call.callLog.callId.orEmpty()
                        if (callId.isNotEmpty()) {
                            Log.i("$TAG Storing our callbacks for call ID [$callId]")
                            map[callId] = callbacks
                        }
                    }
                }
            } catch (ce: CallException) {
                Log.e("$TAG Failed to add call to Telecom's CallsManager: $ce")
            } catch (se: SecurityException) {
                Log.e("$TAG Security exception trying to add call to Telecom's CallsManager: $se")
            } catch (ise: IllegalArgumentException) {
                Log.e("$TAG Illegal argument exception trying to add call to Telecom's CallsManager: $ise")
            } catch (e: Exception) {
                Log.e("$TAG Exception trying to add call to Telecom's CallsManager: $e")
            }
        }
    }

    @WorkerThread
    fun onCoreStarted(core: Core) {
        Log.i("$TAG Core has been started")
        if (hasTelecomFeature) {
            core.addListener(coreListener)
        } else {
            Log.w(
                "$TAG android.software.telecom feature is not available, enable audio focus requests in Linphone SDK"
            )
            coreContext.core.config.setBool("audio", "android_disable_audio_focus_requests", false)
        }
    }

    @WorkerThread
    fun onCoreStopped(core: Core) {
        Log.i("$TAG Core is being stopped")
        if (hasTelecomFeature) {
            core.removeListener(coreListener)
        }
    }
}
