/*
 * Copyright (c) 2010-2023 Belledonne Communications SARL.
 *
 * This file is part of linphone-android
 * (see https://www.linphone.org).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package it.softphone.app.ui.call.conference.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.UiThread
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import it.softphone.app.R
import it.softphone.app.core.tools.Log
import it.softphone.app.databinding.CallConferenceAudioOnlyFragmentBinding
import it.softphone.app.ui.call.conference.viewmodel.ConferenceViewModel
import it.softphone.app.ui.call.fragment.GenericCallFragment
import it.softphone.app.ui.call.viewmodel.CurrentCallViewModel

@UiThread
class ConferenceAudioOnlyFragment : GenericCallFragment() {
    companion object {
        private const val TAG = "[Conference Audio Only Fragment]"
    }

    private lateinit var binding: CallConferenceAudioOnlyFragmentBinding

    private lateinit var callViewModel: CurrentCallViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = CallConferenceAudioOnlyFragmentBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        callViewModel = requireActivity().run {
            ViewModelProvider(this)[CurrentCallViewModel::class.java]
        }

        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = callViewModel
        binding.conferenceViewModel = callViewModel.conferenceModel

        callViewModel.conferenceModel.conferenceLayout.observe(viewLifecycleOwner) {
            when (it) {
                ConferenceViewModel.ACTIVE_SPEAKER_LAYOUT -> {
                    Log.i(
                        "$TAG Conference layout changed to active speaker, navigating to matching fragment"
                    )
                    if (findNavController().currentDestination?.id == R.id.conferenceAudioOnlyFragment) {
                        findNavController().navigate(
                            R.id.action_conferenceAudioOnlyFragment_to_conferenceActiveSpeakerFragment
                        )
                    }
                }
                ConferenceViewModel.GRID_LAYOUT -> {
                    Log.i(
                        "$TAG Conference layout changed to mosaic, navigating to matching fragment"
                    )
                    if (findNavController().currentDestination?.id == R.id.conferenceAudioOnlyFragment) {
                        findNavController().navigate(
                            R.id.action_conferenceAudioOnlyFragment_to_conferenceGridFragment
                        )
                    }
                }
                else -> {
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        Log.i("$TAG Making sure we are not in full-screen mode")
        callViewModel.fullScreenMode.value = false
    }
}
