# SoftPhone Android — Integrazione WebPhone

## Cosa è stato modificato rispetto al fork Linphone originale

### Rebranding
| Cosa | Prima | Dopo |
|------|-------|------|
| Nome app | Linphone | SoftPhone |
| Package Android | `org.linphone` | `it.softphone.app` |
| Colore primario | Arancione `#FF5E00` | Blu chiaro `#1E90FF` |
| Tema | `Theme.Linphone` | `Theme.SoftPhone` |

---

## Nuovi file aggiunti — pacchetto `it.softphone.app.webphone`

```
app/src/main/java/it/softphone/app/webphone/
├── WebPhoneApiClient.kt      ← client HTTP verso server WebPhone
├── WebPhoneModels.kt         ← data classes (CallRecord, Conversation, Message, Config…)
├── WebPhoneSseListener.kt    ← connessione SSE real-time (auto-reconnect)
├── WebPhoneSyncManager.kt    ← singleton orchestratore (singleton, StateFlow pubblici)
├── WebPhoneHistoryViewModel.kt  ← ViewModel storico chiamate
├── WebPhoneChatViewModel.kt     ← ViewModel chat
├── WebPhoneHistoryFragment.kt   ← Fragment storico + RecyclerView adapter
├── WebPhoneChatFragment.kt      ← Fragment conversazioni + messaggi + adapter
└── WebPhoneSetupFragment.kt     ← Fragment configurazione (URL, username, password)
```

---

## Sincronizzazione in tempo reale — come funziona

```
SoftPhone Android                    WebPhone Server (Node.js)
      │                                        │
      │  GET /api/calls                        │  storico chiamate (CDR)
      │◄───────────────────────────────────────│
      │                                        │
      │  GET /api/linphone/carddav/:ext/       │  rubrica CardDAV
      │◄───────────────────────────────────────│
      │                                        │
      │  SSE /chat/stream ──── long-poll ─────►│
      │◄── new_message / messages_read ────────│  chat real-time
      │◄── suppress_ring / linphone_status ────│  gestione chiamate
      │◄── call_ended / call_answered ─────────│  storico real-time
```

### Storico chiamate
- Al primo avvio: `GET /api/calls?limit=200` popola la lista
- In tempo reale: l'evento SSE `call_ended`/`call_answered`/`call_missed` aggiunge
  il record in cima alla lista immediatamente
- Osservato da `WebPhoneHistoryFragment` tramite `StateFlow<List<WebPhoneCallRecord>>`

### Rubrica (CardDAV)
- L'URL CardDAV viene calcolato da `WebPhoneSyncManager.cardDavUrl()`
  → `https://<server>/api/linphone/carddav/<ext>/`
- Il provisioning XML (`GET /api/linphone/provision`) configura automaticamente
  l'account SIP + rubrica CardDAV nel Linphone SDK
- L'SDK Linphone sincronizza la rubrica all'avvio e periodicamente in background

### Chat
- Lista conversazioni: `GET /api/chat/conversations` (aggiornato ad ogni evento SSE)
- Messaggi: `GET /api/chat/messages/:id`
- Invio: `POST /api/chat/send`
- Lettura: `POST /api/chat/read`
- Real-time via SSE: `new_message`, `messages_read`, `typing`

### Soppressione ring (Linphone primario)
- Se l'utente ha attivato "Linphone principale" nel WebPhone, l'evento SSE
  `suppress_ring` arriva su `CoreContext.onCallStateChanged(IncomingReceived)`
- Il hook in `CoreContext.kt` sopprime il ring locale lasciando gestire la
  chiamata al WebPhone

---

## Setup primo avvio

### Opzione A — Configurazione manuale
1. Aprire **Impostazioni → WebPhone** (o navigare a `WebPhoneSetupFragment`)
2. Inserire URL server, username e password (stesse del WebPhone)
3. Toccare **Connetti** — il client verifica le credenziali e salva la config

### Opzione B — QR code (consigliata)
1. Nel WebPhone: menu utente → 📞 Linphone → **Mostra QR code**
2. Nell'app: **Impostazioni → Scansiona QR** (usa lo scanner già presente)
3. Inserire username+password quando richiesto
4. L'app scarica il provisioning XML e si configura automaticamente

---

## Aggiungere WebPhone History/Chat come tab predefiniti

Nel file `history_nav_graph.xml` e `chat_nav_graph.xml` sono presenti le
destinazioni `webPhoneHistoryFragment` e `webPhoneChatFragment` commentate.

Per attivarle come sostituto del comportamento nativo:

**1. In `HistoryListFragment.kt`** — sovrascrivere `onViewCreated` per navigare
   a `WebPhoneHistoryFragment` se il sync è attivo:
```kotlin
val syncManager = WebPhoneSyncManager.getInstance(requireContext())
if (syncManager.isConnected.value) {
    // navController.navigate(R.id.action_to_webPhoneHistoryFragment)
}
```

**2. In `ChatListFragment.kt`** — stessa logica per la chat.

In alternativa, i Fragment WebPhone possono essere usati direttamente come
schermate standalone accessibili dal bottom nav aggiungendo una voce
"WebPhone" oppure integrandoli nei fragment esistenti tramite un `ViewPager2`.

---

## Dipendenze richieste (già presenti nel progetto Linphone)

- `okhttp` o connessione HTTP nativa (usata `HttpURLConnection` — nessuna dipendenza extra)
- `kotlinx.coroutines` ✅
- `androidx.lifecycle` (StateFlow, ViewModel) ✅
- `androidx.recyclerview` ✅
- `androidx.cardview` ✅
- `org.json` (Android built-in) ✅

**Nessuna dipendenza aggiuntiva necessaria.**

---

## Struttura SharedPreferences

La configurazione WebPhone è salvata in:
```
SharedPreferences: "webphone_config"
Keys:
  server_url  → "https://pbx.esempio.it"
  username    → "201"
  password    → "••••••"
  extension   → "201"
```

---

## Variabili d'ambiente server WebPhone richieste

Nel file `.env` del server WebPhone (già presente in `server/.env`):
```bash
PBX_HOST=pbx.esempio.it        # hostname pubblico per il provisioning XML
ORIGINATE_CONTEXT=from-internal # contesto AMI per click-to-call
```

Questi sono già documentati in `LINPHONE.md` del progetto WebPhone.
